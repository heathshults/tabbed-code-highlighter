---
title: "{{ replace .Name "-" " " | title }}"
date:  {{ .Date }}
toc: true
layout: baseof
title: HeathenScript RC 1.0.0
slug: "the last part of the url. usually the page name"
description: Welcome to Heathenville - Home of the HeathenScript programming language.
menu:
  sidenav:
    parent: 
    weight: 40
toc: true
---

Lorem Ipsum.