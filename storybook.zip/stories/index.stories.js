import { document, console } from 'global';
import { storiesOf } from '@storybook/html';
import '../assets/css/framekit.css';
import '../assets/js/framekit';

storiesOf('Demo', module)
  .add('heading', () => '<h1>Hello World</h1>')
  .add('button', () => {
    const button = document.createElement('button');
    button.type = 'button';
    button.innerText = 'Hello Button';
    button.addEventListener('click', e => console.log(e));
    return button;
  });

  storiesOf('Button', module)
  .add('primary', () => <Button class={`c-button c-button--primary`} onClick={action('clicked')}>Primary Button</Button>)
  .add('secondary', () => (
    <Button class={`c-button c-button--secondary`} onClick={action('clicked')}>
      Secondary Button
    </Button>
  ))
  .add('destructive', () => (
    <Button class={`c-button c-button--destructive`} onClick={action('clicked')}>
      Secondary Button
    </Button>
  ));
  
  storiesOf('Accordion', module)
  .add('default', () => (

    <div id={`accordion`} class={`c-accordion`}>
    <h1 class={`c-accordion__headline`}>Frequently Asked Questions</h1>
    <section class={`c-accordion__item is-open`}>
        <button role={`button`} aria-controls={`content02`} aria-expanded={`false`} class={`js-acc-control c-accordion__control`}>
           <span class={`c-accordion__icon`}></span>
           Your housing Partner of choice
        </button>
        <div id={`content02`} aria-hidden={`true`} class={`js-ddpanel c-accordion__content`}>
            <p>Lorem ipsum  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua. Ut enim ad uis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
        </div>
    </section>
    <section class={`c-accordion__item`}>
        <button role={`button`} aria-controls={`content03`} aria-expanded={`false`} class={`js-acc-control c-accordion__control`}>
           <span class={`c-accordion__icon`}></span>
           The premiere housing options provider
        </button>
        <div id="control03" aria-hidden={`true`} class={`js-ddpanel c-accordion__content`}>
            <p>Lorem ipsum  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua. Ut enim ad uis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
        </div>
    </section>
    <section class={`c-accordion__item`}>
        <button role={`button`} aria-controls={`content04`} aria-expanded={`false`} class={`js-acc-control c-accordion__control`}>
           <div class={`c-accordion__icon`}></div>
           Financing Options to give you options
        </button>
        <div id={`content04`} aria-hidden={`true`} class={`js-ddpanel c-accordion__content`}>
            <p>Lorem ipsum  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua. Ut enim ad uis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
        </div>
    </section>
    <section class={`c-accordion__item`}>
        <button role={`button`} aria-controls={`content05`} aria-expanded={`false`} class={`js-acc-control c-accordion__control`}>
           <span class={`c-accordion__icon`}></span>
           A stronger market for all
        </button>
        <div id={`content05`} aria-hidden={`true`} class={`js-ddpanel c-accordion__content`}>
            <p>Lorem ipsum  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua. Ut enim ad uis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
        </div>
    </section>

</div>

  ));
