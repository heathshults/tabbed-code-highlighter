import { configure } from '@storybook/html';
// import { addParameters } from '@storybook/react'; // <- or your storybook framework

// automatically import all files ending in *.stories.js
const req = require.context('../stories', true, /\.stories\.js$/);
function loadStories() {
  req.keys().forEach(filename => req(filename));
}

// addParameters({
//   backgrounds: [
//     { name: 'twitter', value: '#00aced', default: true },
//     { name: 'facebook', value: '#3b5998' },
//   ],
// });

configure(loadStories, module);
